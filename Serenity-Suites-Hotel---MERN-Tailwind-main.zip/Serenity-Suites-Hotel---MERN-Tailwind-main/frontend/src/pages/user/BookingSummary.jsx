import React from 'react'

function BookingConfirmation() {
  return (
    <div>
      <h2>BookingConfirmation</h2>
    </div>
  )
}

export default BookingConfirmation

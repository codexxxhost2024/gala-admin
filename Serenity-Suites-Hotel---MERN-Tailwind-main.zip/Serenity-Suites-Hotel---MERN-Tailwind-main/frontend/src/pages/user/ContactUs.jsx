import React from 'react'

export default function ContactUs() {
  return (
    <div>
      <h2>ContactUs</h2>
    </div>
  )
}
